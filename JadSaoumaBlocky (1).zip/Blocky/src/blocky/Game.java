package blocky;

import java.awt.Color;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

public class Game {

    //=== Public Attributes ===
    //root:
    //    The Blocky board on which this game will be played.
    private Block root;

    //highlightedBlock:
    //    The block the user has selected.  This will be colored specially when rendered.
    private Block highlightedBlock;

    public Game() {
//      root = createTestBoard();
        root = new Block();
        createRandomChildren(root);
        highlightedBlock = null;
    }

    public void createRandomChildren(Block parent) {
        
        Block miniChildrens = new Block();
        miniChildrens.setLevel(parent.getLevel() + 1);
        miniChildrens.setSize(parent.getSize() / 2);
        List<Block> child = new ArrayList<Block>();
        int rand = 0;
//        child.add(new Block(Block.PACIFIC_POINT, 1, 320, parent));
//        child.add(new Block(Block.REAL_RED, 1, 320, parent));
//        child.add(new Block(Block.DAFFODIL_DELIGHT, 1, 320, parent));
//        child.add(new Block(Block.OLD_OLIVE, 1, 320, parent));
//        parent.setChildren(child);
//
//        int level = miniChildrens.getLevel();
//
//        for (int i = 0; i < 4; i++) {
//            child = new ArrayList<>();
//            int rand = (int) (Math.random() * 6);
//            miniChildrens = parent.getChildren().get(i);
//            if (Math.random() < Math.exp(-0.25 * level)) {
//
//                if (miniChildrens.getLevel() < (Block.MAX_DEPTH)) {
//                    for (int j = 0; j < 4; j++) {
//                        child.add(new Block(Block.COLORS[rand], miniChildrens.getLevel(), miniChildrens.getSize() / 2, miniChildrens));
//                        rand = (int) (Math.random() * 6);
//                    }
//                }
//                miniChildrens.setChildren(child);
//            }
//        }
        for (int i = 0; i < 4; i++) {
            rand = (int) (Math.random() * 6);
            child.add(new Block(Block.COLORS[rand], miniChildrens.getLevel(), miniChildrens.getSize(), parent));
            parent.setChildren(child);
        }
        for (int j = 0; j < parent.getChildren().size(); j++) {
            if (miniChildrens.getLevel() < Block.MAX_DEPTH) {
                if (Math.random() < Math.exp(-0.25 * miniChildrens.getLevel())) {
                    createRandomChildren(parent.getChildren().get(j));
                }
            }
        }
//        Block miniChildren = new Block();
//        miniChildren.setLevel(parent.getLevel() + 2);
//        miniChildren.setSize(parent.getSize() / 4);
//        level = miniChildren.getLevel();
//        int blockLocation = (int) (Math.random() * 4);
//        for (int h = 0; h < 4; h++) {
//           
//            children = parent.getChildren().get(h);
//            if (Math.random() < Math.exp(-0.25 * level)) {
//                blockLocation = (int) (Math.random() * 4);
//                if (miniChildren.getLevel() < (Block.MAX_DEPTH)) {
//                    try {
//                        child = new ArrayList<>();
//                        miniChildren = children.getChildren().get(blockLocation);
//                    } catch (java.lang.IndexOutOfBoundsException e) {
//                    }
//                    for (int j = 0; j < 4; j++) {
//                        
//                        int rand = (int) (Math.random() * 6);
//                        child.add(new Block(Block.COLORS[rand], miniChildren.getLevel() + 1, miniChildren.getSize() / 2, miniChildren));
//                        miniChildren.setChildren(child);
//                    }
//                }
//            }
//        }
//        Block varyMiniChildren = new Block();
//        varyMiniChildren.setLevel(parent.getLevel() + 3);
//        varyMiniChildren.setSize(parent.getSize() / 8);
//        level = varyMiniChildren.getLevel();
//        int k = 0;
//        while (k < 4) {
//            children = parent.getChildren().get(k);
//            if (Math.random() < Math.exp(-0.25 * level)) {
//                k++;
//                if (varyMiniChildren.getLevel() < (Block.MAX_DEPTH)) {
//                    for (int a = 0; a < 4; a++) {
//                        try {
//                            child = new ArrayList<>();
//                            miniChildren = children.getChildren().get(a);
//                        } catch (java.lang.IndexOutOfBoundsException e) {
//                            
//                        }
//                        for (int j = 0; j < 4; j++) {
//                            try {
//                                blockLocation = (int) (Math.random() * 4);
//                                varyMiniChildren = miniChildren.getChildren().get(blockLocation);
//                            } catch (java.lang.IndexOutOfBoundsException e) {
//
//                            }
//                            int rand = (int) (Math.random() * 4);
//                            child.add(new Block(Block.COLORS[rand], varyMiniChildren.getLevel(), varyMiniChildren.getSize() / 2, varyMiniChildren));
//                            varyMiniChildren.setChildren(child);
//                        }
//                    }
//                }
//
//            }
//        }
    }

    public Block createTestBoard() {
        Block root = new Block();
        root.setSize(Block.MAX_SIZE);

        List<Block> rootChildren = new ArrayList<>();
        rootChildren.add(new Block(Block.DAFFODIL_DELIGHT, 1, 320, root));
        rootChildren.add(new Block(Block.OLD_OLIVE, 1, 320, root));
        rootChildren.add(new Block(Block.PACIFIC_POINT, 1, 320, root));
        rootChildren.add(new Block(Block.REAL_RED, 1, 320, root));

        root.setChildren(rootChildren);
        Block child = root.getChildren().get(0);

        rootChildren = new ArrayList<>();
        rootChildren.add(new Block(Block.DAFFODIL_DELIGHT, 2, 160, child));
        rootChildren.add(new Block(Block.OLD_OLIVE, 2, 160, child));
        rootChildren.add(new Block(Block.PACIFIC_POINT, 2, 160, child));
        rootChildren.add(new Block(Block.REAL_RED, 2, 160, child));

        child.setChildren(rootChildren);

        return root;
    }

    public Block getRoot() {
        return root;
    }

    public Block getHighlightedBlock() {
        return highlightedBlock;
    }

    public void setRoot(Block root) {
        this.root = root;
    }

    public void setHighlightedBlock(Block highlightedBlock) {
        this.highlightedBlock = highlightedBlock;
    }
   
}
